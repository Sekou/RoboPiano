lengths={7, 5, 3, 2}
-----------------------------------
function motion(T) 

setA(0, getA(0)+1)
setA(1, 2*getA(0))
setA(2, 2*getA(1))
setA(3, 2*getA(2))

end
-----------------------------------
draw_params={
draw_manipulator=true, 
draw_path=true,
clear_manipulator=true,
speed=1,
fade=20,
thickness=2
}
-----------------------------------
init_manipulator(lengths, "motion", draw_params)


