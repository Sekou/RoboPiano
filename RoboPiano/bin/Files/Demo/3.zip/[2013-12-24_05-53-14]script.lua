lengths={7, 5, 3}

init_coeffs(lengths)

-----------------------------------
function motion(T) 

use_coeffs(T, lengths)

end
-----------------------------------
draw_params={
draw_manipulator=true, 
draw_path=true,
clear_manipulator=true,
speed=1,
fade=0,
thickness=2
}
-----------------------------------
init_manipulator(lengths, "motion", draw_params)

